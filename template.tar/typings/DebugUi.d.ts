import { Composite } from './game/ui/Composite';
export declare class DebugUi extends Composite {
    constructor();
    private sceneSetup();
}
