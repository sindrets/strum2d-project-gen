export declare enum CollisionType {
    LEFT = 1,
    TOP = 2,
    RIGHT = 3,
    BOTTOM = 4,
}
