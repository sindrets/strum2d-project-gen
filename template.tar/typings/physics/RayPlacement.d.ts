export declare enum RayPlacement {
    BOTTOM_LEFT = 1,
    BOTTOM_RIGHT = 2,
    TOP_LEFT = 3,
    TOP_RIGHT = 4,
    LEFT = 5,
    TOP = 6,
    RIGHT = 7,
    BOTTOM = 8,
}
