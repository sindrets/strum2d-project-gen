export declare abstract class LayoutManager {
    abstract layout(): void;
}
