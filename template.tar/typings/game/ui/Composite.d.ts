import { Component } from "../Component";
import { CoordSpace } from "../Entity";
export declare class Composite extends Component {
    stack: Component[];
    addComponent(o: Component): void;
    setPrefferedCoordSpace(value: CoordSpace): void;
    pushAsUi(): void;
    pushAsWorld(): void;
    draw(g2: CanvasRenderingContext2D): void;
    tick(): void;
}
