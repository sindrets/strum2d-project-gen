import { Component } from "../Component";
import { Point } from "../../maths/Point";
import { TextModuleHandler } from "./TextModuleHandler";
export declare abstract class TextModule extends Component {
    text: string;
    protected placeholder: string;
    protected fontSize: number;
    protected font: Font | string;
    protected alignment: TextAlignment;
    filter?: RegExp;
    protected primaryColor: string;
    protected secondaryColor: string;
    protected textColor: string;
    protected selectedColor: string;
    protected highlightColor: string;
    cursorIndex: number;
    protected cursorColor: string;
    protected cursorBlink: number;
    protected cursorWidth: number;
    cursorX: number;
    offsetX: number;
    protected behindCursor: string;
    protected pastCursor: string;
    protected behindCursorWidth: number;
    protected pastCursorWidth: number;
    protected textWidth: number;
    protected textHeight: number;
    protected marginLeft: number;
    protected marginTop: number;
    protected marginRight: number;
    protected marginBottom: number;
    selection: string;
    selectionRange: [number, number];
    hasSelection: boolean;
    isInputModule: boolean;
    selected: boolean;
    handler: TextModuleHandler;
    onInput?: () => void;
    updateDimensions(): void;
    protected applyFont(): void;
    setCursorIndex(index: number): void;
    modCursorIndex(amount: number): void;
    updateCursor(): void;
    setCursorClosestTo(p: Point): void;
    updateSelection(): void;
    widthOfTextRange(start: number, end: number): number;
    protected xOfIndex(index: number): number;
    protected measureString(text: string): TextMetrics;
    selectAll(): void;
    deselectAll(): void;
    appendText(text: string, index?: number, ignoreSelection?: boolean): void;
    setText(text: string): void;
    setPlaceholder(text: string): void;
    setFontSize(size: number): void;
    setFont(font: Font | string, size?: number): void;
    setTextAlignment(alignment: TextAlignment): void;
    setFilter(filter: RegExp | undefined): void;
    setTextColor(color: string): void;
    setSelected(flag: boolean): void;
    deselectText(): void;
    setInputModule(flag: boolean): void;
    setMargin(amount: number): void;
    setMarginLeft(amount: number): void;
    setMarginTop(amount: number): void;
    setMarginRight(amount: number): void;
    setMarginBottom(amount: number): void;
    getMarginLeft(): number;
    getMarginTop(): number;
    getMarginRight(): number;
    getMarginBottom(): number;
    getText(): string;
    getPlaceholder(): string;
    getFontSize(): number;
    getFont(): string;
    getTextAlignment(): TextAlignment;
    getSelection(): string;
    getSelectionRange(): [number, number];
    getInnerWidth(): number;
}
export declare enum TextAlignment {
    LEFT_TO_RIGHT = 0,
    RIGHT_TO_LEFT = 1,
    CENTERED = 2,
}
export declare enum Font {
    GEORGIA = "Georgia",
    PALATINO = "Palatino Linotype",
    ANTIQUA = "Book Antiqua",
    TIMES_NEW_ROMAN = "Times New Roman",
    SERIF = "serif",
    ARIAL = "Arial",
    ARIAL_BLACK = "Arial Black",
    HELVETICA = "Helvetica",
    GADGET = "Gadget",
    IMPACT = "Impact",
    CHARCOAL = "Charcoal",
    LUCIDA_SANS = "Lucida Sans Unicode",
    TAHOMA = "Tahoma",
    GENEVA = "Geneva",
    TREBUCHET = "Trebuchet MS",
    VERDANA = "Verdana",
    SANS_SERIF = "sans-serif",
    CONSOLAS = "Consolas",
    COURIER_NEW = "Courier New",
    LUCIDA_CONSOLE = "Lucida Console",
    MONOSPACE = "monospace",
}
