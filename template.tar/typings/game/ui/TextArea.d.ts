import { TextModule, Font } from "./TextModule";
export declare class TextArea extends TextModule {
    private lines;
    private lineScale;
    constructor(text?: string, x?: number, y?: number);
    updateDimensions(): void;
    setText(text: string): void;
    appendText(text: string): void;
    setFont(font: Font | string, size?: number): void;
    setFontSize(size: number): void;
    setLineScale(multiplier: number): void;
    getLineScale(): number;
    draw(g2: CanvasRenderingContext2D): void;
    tick(): void;
}
