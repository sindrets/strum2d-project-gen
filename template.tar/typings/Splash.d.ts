import { Scene } from './game/Scene';
export declare class Splash extends Scene {
    private duration;
    private start;
    constructor();
    load(): void;
    initScene(): void;
    tick(): void;
}
