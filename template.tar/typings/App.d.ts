export declare class Program extends Strum2d.Scene {
    constructor();
    load(): void;
    initScene(): void;
    tick(): void;
}
