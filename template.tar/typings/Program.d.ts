import { Strum2d } from "../@types/index";
export declare class Program extends Strum2d.Scene {
    constructor();
    initScene(): void;
}
