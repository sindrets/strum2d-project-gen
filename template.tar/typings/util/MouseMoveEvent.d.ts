import { Point } from "../maths/Point";
import { MouseButton } from "./MouseHandler";
export declare class MouseMoveEvent {
    origins: Point[];
    point: Point;
    inBounds: boolean;
    buttons: MouseButton[];
    constructor(origins: Point[], point: Point, inBounds: boolean, buttons: MouseButton[]);
}
