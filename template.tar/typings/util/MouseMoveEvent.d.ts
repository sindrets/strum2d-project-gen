import { Point } from "../maths/Point";
import { MouseButton } from "./MouseHandler";
export declare class MouseMoveEvent {
    point: Point;
    inBounds: boolean;
    buttons: MouseButton[];
    constructor(point: Point, inBounds: boolean, buttons: MouseButton[]);
}
