import { MultiKeyEvent } from "./MultiKeyEvent";
export declare class KeyHandler {
    keyPressed?: (e: KeyboardEvent) => void;
    keyDown?: (e: KeyboardEvent) => void;
    keyUp?: (e: KeyboardEvent) => void;
    static preventDefault(): void;
    tick(e: MultiKeyEvent): void;
}
