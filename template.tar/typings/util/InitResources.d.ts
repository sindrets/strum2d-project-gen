export declare function initResources(): void;
