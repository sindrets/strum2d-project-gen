export declare class Clipboard {
    static copyData: string;
    static pasteData: string;
    static setCopyData(data: string): void;
    static setPasteData(data: string): void;
    static getCopyData(): string;
    static getPasteData(): string;
}
