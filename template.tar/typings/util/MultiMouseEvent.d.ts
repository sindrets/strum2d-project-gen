export declare class MultiMouseEvent {
    mouseMove?: MouseEvent;
    mouseDown?: MouseEvent;
    mouseUp?: MouseEvent;
    constructor(mouseMoveEvent?: MouseEvent, mouseDownEvent?: MouseEvent, mouseUpEvent?: MouseEvent);
}
