import { Point } from "../maths/Point";
import { Vector2 } from "../maths/Vector2";
export declare class Utils {
    static mouseX: number;
    static mouseY: number;
    static toRadians(degrees: number): number;
    static toDegrees(radians: number): number;
    static dif(a: number, b: number): number;
    static getMousePos(): Point;
    static toWorldPos(p: Point): Point;
    static toCameraPos(p: Point): Point;
    static getWorldPos(): Point;
    static toCanvasPos(clientPos: Point): Point;
    static clamp(value: number, min: number, max: number): number;
    static rangeIntersect(min0: number, max0: number, min1: number, max1: number): boolean;
    static sameSign(a: number, b: number): boolean;
    static vecToDeg(vec: Vector2): number;
    static degToVec(degrees: number): Vector2;
    static lerp(a: number, b: number, t: number): number;
    static getRotatedPos(pos: Point): Point;
    static getInverseRotatedPos(pos: Point): Point;
    static spliceFirst(array: Array<any>): any;
    static spliceLast(array: Array<any>): any;
    static logisticProgression(t: number, a: number, b: number): number;
    static cubicBezier(t: number, c1: Point, c2: Point, c0?: Point, c3?: Point): number;
    static cutStr(text: string, index: number, deleteCount: number): string;
    static cutString(text: string, start: number, end: number): string;
    static loadFont(fontName: string, url: string, properties?: {
        fontStyle: string;
        fontWeight: string;
    }): void;
    static loadFontFace(fontName: string, url: string, callback?: (fontFace: any) => void): void;
    static fmod(a: number, b: number): number;
}
