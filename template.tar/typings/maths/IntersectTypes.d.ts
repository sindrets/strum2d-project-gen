export declare enum IntersectTypes {
    DONT_INTERSECT = 0,
    COLLINEAR = 1,
    DO_INTERSECT = 2,
}
