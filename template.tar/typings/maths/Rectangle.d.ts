import { Point } from "./Point";
export declare class Rectangle {
    width: number;
    height: number;
    x: number;
    y: number;
    constructor(width: number, height: number, x?: number, y?: number);
    contains(point: Point): boolean;
    rectIntersect(rect: Rectangle): boolean;
    clone(): Rectangle;
    draw(g2: CanvasRenderingContext2D): void;
}
