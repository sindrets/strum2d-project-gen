export declare class Vector2 {
    x: number;
    y: number;
    constructor(x: number, y: number);
    update(x: number, y: number): void;
    add(vec: Vector2): Vector2;
    subtract(vec: Vector2): Vector2;
    multiplyNum(multiplier: number): Vector2;
    getLength(): number;
    cross(vec: Vector2): number;
    dot(vec: Vector2): number;
    unit(): Vector2;
    inverse(): Vector2;
    /** Adjusts the magnitude of the vector by specified amount */
    resize(length: number): void;
    /** Linearily interpolate between two vectors */
    static lerp(v0: Vector2, v1: Vector2, t: number): Vector2;
}
