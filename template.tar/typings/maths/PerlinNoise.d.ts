export declare class PerlinNoise {
    static octaveNoise(x: number, y?: number, z?: number, octaves?: number, frequency?: number, persistence?: number): number;
    static noise(x: number, y: number, z: number): number;
    private static fade(t);
    private static lerp(t, a, b);
    private static grad(hash, x, y, z);
    private static p;
    private static permutation;
    private static _constructor;
}
