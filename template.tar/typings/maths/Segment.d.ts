import { Point } from "./Point";
import { Vector2 } from "./Vector2";
import { SegmentIntersectionEvent } from "./SegmentIntersectionEvent";
export declare class Segment {
    x: number;
    y: number;
    vecX: number;
    vecY: number;
    constructor(x: number, y: number, vecX: number, vecY: number);
    update(x?: number, y?: number, vecX?: number, vecY?: number): void;
    draw(g2: CanvasRenderingContext2D): void;
    getLength(): number;
    getNormal(): Segment;
    getCenter(): Point;
    getUnit(): Segment;
    getVector(): Vector2;
    multiply(multiplier: number): void;
    divide(divisor: number): void;
    resize(length: number): void;
    clone(): Segment;
    intersect(seg: Segment): SegmentIntersectionEvent;
}
